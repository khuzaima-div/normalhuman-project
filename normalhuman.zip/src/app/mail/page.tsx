"use client"

// src/app/mail/page.tsx
import ThemeToggle from '@/components/theme-toggle'
import { UserButton } from '@clerk/nextjs'
import dynamic from 'next/dynamic'
import React from 'react'
import ComposeButton from '@/components/email-editor/compose-button'

// Hydration issues se bachne ke liye Mail component bina SSR ke dynamically load ho raha hai
const Mail = dynamic(() => {
    return import('./mail')
}, {
    ssr: false
})

const MailDashboard = () => {
    return (
        <>
            {/* 🎨 Bottom Left absolute container holding profile, dark mode toggle & premium Compose button */}
            <div className="absolute bottom-4 left-4 z-50">
                <div className="flex items-center gap-2">
                    <UserButton />
                    <ThemeToggle />
                    <ComposeButton />
                </div>
            </div>

            {/* Main Resizable Mail Component Panel */}
            <Mail
                defaultLayout={[20, 32, 48]}
                defaultCollapsed={false}
                navCollapsedSize={4}
            />
        </>
    )
}

export default MailDashboard