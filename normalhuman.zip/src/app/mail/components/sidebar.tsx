"use client"

import React from "react"
import { useLocalStorage } from "usehooks-ts"
import { Inbox, File, Send, Sun, Moon } from "lucide-react"
import { useTheme } from "next-themes" // 👈 Theme control karne ke liye hook import kiya
import { api } from "@/trpc/react"
import { useAccountSelection } from "@/hooks/use-account-selection"
import { Nav } from "./nav"
import { cn } from "@/lib/utils"

interface SidebarProps {
  isCollapsed: boolean
}

export function SideBar({ isCollapsed }: SidebarProps) {
  const { accountId } = useAccountSelection()
  const [tab, setTab] = useLocalStorage<'inbox' | 'draft' | 'sent'>("normalhuman-tab", "inbox")
  const { theme, setTheme } = useTheme() // 👈 Active theme access kiya

  const { data: inboxThreads } = api.account.getNumThreads.useQuery(
    { accountId: accountId ?? "", tab: "inbox" },
    { enabled: !!accountId }
  )
  const { data: draftThreads } = api.account.getNumThreads.useQuery(
    { accountId: accountId ?? "", tab: "draft" },
    { enabled: !!accountId }
  )
  const { data: sentThreads } = api.account.getNumThreads.useQuery(
    { accountId: accountId ?? "", tab: "sent" },
    { enabled: !!accountId }
  )

  return (
    <div className="flex flex-col h-full bg-white dark:bg-zinc-950 justify-between transition-colors duration-300">
      {/* Top Section: Navigation Links */}
      <div className="flex-1 py-2">
        <Nav
          isCollapsed={isCollapsed}
          onTabChange={(id: string) => setTab(id as 'inbox' | 'draft' | 'sent')}
          links={[
            {
              title: "Inbox",
              label: inboxThreads?.toString() ?? "0", 
              icon: Inbox,
              variant: tab === "inbox" ? "default" : "ghost",
              id: "inbox"
            },
            {
              title: "Draft",
              label: draftThreads?.toString() ?? "0",
              icon: File,
              variant: tab === "draft" ? "default" : "ghost",
              id: "draft"
            },
            {
              title: "Sent",
              label: sentThreads?.toString() ?? "0",
              icon: Send,
              variant: tab === "sent" ? "default" : "ghost",
              id: "sent"
            }
          ]}
        />
      </div>
    </div>
  )
}