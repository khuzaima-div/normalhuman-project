"use client"

import React from "react"
import { format } from "date-fns"
import {
  Archive,
  ArchiveX,
  Clock,
  MoreVertical,
  Trash2,
} from "lucide-react"

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../../../components/ui/dropdown-menu"
import {
  Avatar as ShadcnAvatar,
  AvatarFallback,
} from "../../../components/ui/avatar"
import { Button } from "../../../components/ui/button"
import { Separator } from "../../../components/ui/separator"
import { Tooltip, TooltipContent, TooltipTrigger } from "../../../components/ui/tooltip"

import { useThreads } from "../../../hooks/use-threads"
import EmailDisplay from "./email-display"
// 📬 Premium ReplyBox import loop hook call
import ReplyBox from "@/components/email-editor/reply-box"

type ThreadDisplayProps = {
  threadId?: string | null
  emailId?: string | null
}

export function ThreadDisplay({
  threadId: threadIdProp,
  emailId: selectedEmailIdProp,
}: ThreadDisplayProps) {
  const threadId = threadIdProp ?? null
  const { threads, accountId } = useThreads()
  const [selectedEmailId, setSelectedEmailId] = React.useState<string | null>(selectedEmailIdProp ?? null)

  React.useEffect(() => {
    if (selectedEmailIdProp !== undefined) {
      setSelectedEmailId(selectedEmailIdProp)
      return
    }

    if (!selectedEmailId && threadId) {
      const thread = threads?.find((t) => t.id === threadId)
      setSelectedEmailId(thread?.emails?.[0]?.id ?? null)
    }
  }, [selectedEmailIdProp, selectedEmailId, threadId, threads])

  const thread = threads?.find((t) => t.id === threadId)

  console.log('DEBUG: ThreadDisplay render', { threadId, accountId, hasThread: !!thread })

  return (
    <div className="flex flex-col h-full overflow-hidden bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100">
      
      {/* 1. Top Controls Bar - Explicit borders and visibility */}
      <div className="flex items-center justify-between p-3 border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/50 shrink-0 min-h-13">
        <div className="flex items-center gap-1">
          <Tooltip delayDuration={0}>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" disabled={!thread} className="h-8 w-8 text-zinc-500 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800">
                <Archive className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Archive</TooltipContent>
          </Tooltip>

          <Tooltip delayDuration={0}>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" disabled={!thread} className="h-8 w-8 text-zinc-500 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800">
                <ArchiveX className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Junk</TooltipContent>
          </Tooltip>

          <Tooltip delayDuration={0}>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" disabled={!thread} className="h-8 w-8 text-zinc-500 dark:text-zinc-400 hover:text-rose-500 hover:bg-zinc-200 dark:hover:bg-zinc-800">
                <Trash2 className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Trash</TooltipContent>
          </Tooltip>

          <Separator orientation="vertical" className="h-4 mx-1 bg-zinc-300 dark:bg-zinc-700" />

          <Tooltip delayDuration={0}>
            <Button variant="ghost" size="icon" disabled={!thread} className="h-8 w-8 text-zinc-500 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800">
              <Clock className="w-4 h-4" />
            </Button>
            <TooltipContent>Snooze</TooltipContent>
          </Tooltip>
        </div>

        <div className="flex items-center gap-1">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" disabled={!thread} className="h-8 w-8 text-zinc-500 dark:text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-800">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
              <DropdownMenuItem>Mark as unread</DropdownMenuItem>
              <DropdownMenuItem>Star thread</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* 2. Main Body Container */}
      {thread ? (
        <div className="flex flex-col flex-1 min-h-0 overflow-hidden">
          
          {/* Thread Header Block */}
          <div className="flex items-start gap-4 p-5 border-b border-zinc-200/80 dark:border-zinc-800/80 bg-zinc-50/90 dark:bg-zinc-950/90 shrink-0">
            <div className="flex items-start gap-3 text-sm min-w-0 flex-1">
              <ShadcnAvatar className="h-11 w-11 border border-zinc-200 dark:border-zinc-800 shrink-0">
                <AvatarFallback className="bg-zinc-100 dark:bg-zinc-900 text-zinc-800 dark:text-zinc-200 font-bold text-sm">
                  {thread.emails?.[0]?.from?.name?.charAt(0) || "E"}
                </AvatarFallback>
              </ShadcnAvatar>
              
              <div className="grid gap-1 min-w-0">
                <div className="font-semibold text-zinc-900 dark:text-zinc-50 text-base truncate">
                  {thread.emails?.[0]?.from?.name || "Unknown Sender"}
                </div>
                <div className="text-sm font-semibold text-zinc-700 dark:text-zinc-300 line-clamp-1">
                  {thread.emails?.[0]?.subject}
                </div>
                <div className="text-[12px] text-zinc-500 dark:text-zinc-400 truncate">
                  <span className="font-medium text-zinc-400">Reply-To:</span> {thread.emails?.[0]?.from?.address}
                </div>
              </div>
            </div>

            {thread.emails?.[0]?.sentAt && (
              <div className="ml-auto pl-2 text-[11px] text-zinc-400 dark:text-zinc-500 font-mono whitespace-nowrap pt-0.5">
                {format(new Date(thread.emails[0].sentAt), "MMM d, yyyy, h:mm a")}
              </div>
            )}
          </div>

          {/* 3. 🛠️ CORE SCROLLABLE EMAILS FEED STACK - FIXED FOR FULL SIZE LAYOUT */}
          <div className="flex-1 min-h-0 overflow-y-auto bg-zinc-50/70 dark:bg-zinc-950 p-4 space-y-4">
            {thread.emails.map((email, index) => (
              <div 
                key={email.id} 
                className={`w-full ${
                  index !== thread.emails.length - 1 ? 'border-b border-zinc-200 dark:border-zinc-800/80' : ''
                }`}
              >
                <EmailDisplay
                  email={{
                    ...email,
                    body: email.body ?? undefined,
                  }}
                />
              </div>
            ))}
          </div>

          {/* 🌟 FIXED EDGE-TO-EDGE PLACEMENT */}
          <div className="w-full bg-white dark:bg-zinc-950 shrink-0 border-t border-zinc-200 dark:border-zinc-800 mt-auto">
            <ReplyBox />
          </div>

        </div>
      ) : (
        <div className="flex h-full items-center justify-center p-8 text-center text-zinc-400 dark:text-zinc-500">
          <p className="text-sm font-medium">No message selected</p>
        </div>
      )}
    </div>
  )
}