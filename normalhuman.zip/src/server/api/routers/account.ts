import { z } from "zod"
import { createTRPCRouter, privateProcedure } from "../trpc"
import { PrismaClient } from "@prisma/client"
import { TRPCError } from "@trpc/server"

/**
 * Type-safe access validator mapping Prisma client interface structures explicitly
 */
export const authoriseAccountAccess = async (
    accountId: string, 
    userId: string, 
    db: PrismaClient
) => {
    const account = await db.account.findFirst({
        where: {
            id: accountId,
            userId: userId,
        },
        select: {
            id: true,
            emailAddress: true,
            name: true,
            accessToken: true,
        }
    })
    if (!account) throw new Error('Account not found')
    return account
}

export const accountRouter = createTRPCRouter({
    // Get accounts router query
    getAccounts: privateProcedure.query(async ({ ctx }) => {
        return await ctx.db.account.findMany({
            where: { userId: ctx.auth.userId },
            orderBy: { id: 'desc' },
            select: { id: true, emailAddress: true, name: true }
        })
    }),

    // Get live threads count router query
    getNumThreads: privateProcedure
        .input(z.object({
            accountId: z.string(),
            // 🔥 FIX: Agar frontend se tab undefined ya null aaye to automatic 'inbox' set ho jaye
            tab: z.string().nullish().default("inbox"),
        }))
        .query(async ({ ctx, input }) => {
            const account = await authoriseAccountAccess(input.accountId, ctx.auth.userId, ctx.db)

            let filter: Record<string, any> = {}
            const currentTab = input.tab ?? 'inbox';

            if (currentTab === 'inbox') {
                filter.inboxStatus = true
            } else if (currentTab === 'draft') {
                filter.draftStatus = true
            } else if (currentTab === 'sent') {
                filter.sentStatus = true
            } else if (currentTab === 'done') {
                filter.doneStatus = true
            }

            return await ctx.db.thread.count({
                where: {
                    accountId: account.id,
                    ...filter
                }
            })
        }),

    // 🌟 ELLIOTT'S NEW DYNAMIC THREADS FETCHING PROCEDURE (BULLETPROOF VERSION)
    getThreads: privateProcedure
        .input(z.object({
            accountId: z.string(),
            // 🔥 FIX: nullish().default(...) lagane se validation kabhi fail nahi hogi
            tab: z.string().nullish().default("inbox"),
            done: z.boolean().nullish().default(false)
        }))
        .query(async ({ ctx, input }) => {
            // 1. Authorise user access safely
            const account = await authoriseAccountAccess(input.accountId, ctx.auth.userId, ctx.db)

            // Safe fallback clean variables
            const safeTab = input.tab ?? "inbox";
            const safeDone = input.done ?? false;

            // 2. Setup dynamic filters for folder tabs using safe generic records
            let filter: Record<string, any> = {}

            if (safeTab === 'inbox') {
                filter.inboxStatus = true
            } else if (safeTab === 'draft') {
                filter.draftStatus = true
            } else if (safeTab === 'sent') {
                filter.sentStatus = true
            }

            // 3. Filter based on done/archive toggle state
            filter.done = safeDone

            // 4. Fetch deeply nested and relational email items cleanly
            return await ctx.db.thread.findMany({
                where: {
                    accountId: account.id,
                    ...filter
                },
                include: {
                    emails: {
                        orderBy: {
                            sentAt: 'asc' // Oldest to newest emails within a thread chain
                        },
                        select: {
                            from: true,
                            body: true,
                            bodySnippet: true,
                            emailLabel: true,
                            subject: true,
                            sysLabels: true,
                            id: true,
                            sentAt: true
                        }
                    }
                },
                take: 15, // Infinite scroll chunk size
                orderBy: {
                    lastMessageDate: 'desc' // Newest active thread updates stay on top
                }
            })
        }),

    // 📬 image_88fdbf.jpg: Auto-Suggestions Fetcher Pattern
    getSuggestions: privateProcedure
        .input(z.object({
            accountId: z.string(),
        }))
        .query(async ({ ctx, input }) => {
            const account = await authoriseAccountAccess(input.accountId, ctx.auth.userId, ctx.db);
            
            return await ctx.db.emailAddress.findMany({
                where: {
                    accountId: account.id
                },
                select: {
                    address: true,
                    name: true
                }
            });
        }),

    // 🔄 image_890081.jpg & image_88fdbf.jpg: Perfect Reply Metadatas Dynamic Resolver
    getReplyDetails: privateProcedure
        .input(z.object({
            accountId: z.string(),
            threadId: z.string(),
        }))
        .query(async ({ ctx, input }) => {
            const account = await authoriseAccountAccess(input.accountId, ctx.auth.userId, ctx.db);
            
            const thread = await ctx.db.thread.findFirst({
                where: {
                    id: input.threadId,
                },
                include: {
                    emails: {
                        orderBy: { sentAt: 'asc' },
                        select: {
                            id: true,
                            from: true,
                            to: true,
                            cc: true,
                            bcc: true,
                            sentAt: true,
                            subject: true,
                            internetMessageId: true,
                        }
                    }
                }
            });

            if (!thread || thread.emails.length === 0) {
                throw new TRPCError({ code: "NOT_FOUND", message: "Thread not found" });
            }

            const fallbackEmail = thread.emails[thread.emails.length - 1]!;
            const lastExternalEmail = [...thread.emails].reverse().find(
                email => email.from.address !== account.emailAddress
            ) ?? fallbackEmail;

            return {
                subject: lastExternalEmail.subject,
                to: [lastExternalEmail.from, ...lastExternalEmail.to.filter(to => to.address !== account.emailAddress)],
                cc: lastExternalEmail.cc.filter(cc => cc.address !== account.emailAddress),
                from: { name: account.name, address: account.emailAddress },
                id: lastExternalEmail.internetMessageId,
            };
        }),
})